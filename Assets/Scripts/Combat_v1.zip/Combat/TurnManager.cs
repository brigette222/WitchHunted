using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class TurnManager : MonoBehaviour
{
    [SerializeField] private float nextTurnDelay = 1.0f;

    private List<Character> characters = new List<Character>();
    private int curCharacterIndex = -1;
    public Character CurrentCharacter;

    public event UnityAction<Character> OnBeginTurn;
    public event UnityAction<Character> OnEndTurn;

    public static TurnManager Instance;

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
        }
        else
        {
            Instance = this;
        }
    }

    void OnEnable()
    {
        Character.OnDie += OnCharacterDie;
    }

    void OnDisable()
    {
        Character.OnDie -= OnCharacterDie;
    }

    public void StartCombat(Character player, Character enemy)
    {
        Debug.Log($"[TurnManager] Starting combat between Player ({player.name}) and Enemy ({enemy.name})");

        characters.Clear();
        RegisterCharacter(player);
        RegisterCharacter(enemy);

        curCharacterIndex = -1;

        Debug.Log($"[TurnManager] Player starts with {player.CurHp}/{player.MaxHp} HP");
        Debug.Log($"[TurnManager] Enemy starts with {enemy.CurHp}/{enemy.MaxHp} HP");

        BeginNextTurn();
    }

    public void RegisterCharacter(Character character)
    {
        if (!characters.Contains(character))
        {
            characters.Add(character);
            Debug.Log($"[TurnManager] Registered character: {character.name}");
        }
    }

    public void BeginNextTurn()
    {
        curCharacterIndex++;

        if (curCharacterIndex >= characters.Count)
        {
            curCharacterIndex = 0;
        }

        CurrentCharacter = characters[curCharacterIndex];

        if (CurrentCharacter == null)
        {
            Debug.LogError("[TurnManager] CurrentCharacter is NULL at turn start! Something is very wrong.");
            return;
        }

        Debug.Log($"[TurnManager] It is now {CurrentCharacter.name}'s turn. IsPlayer = {CurrentCharacter.IsPlayer}");

        // This is the ONLY thing needed to start the turn.
        // EnemyAI already listens for OnBeginTurn itself � you never needed me to manually "call" anything here.
        OnBeginTurn?.Invoke(CurrentCharacter);
    }

    public void EndTurn()
    {
        if (CurrentCharacter == null)
        {
            Debug.LogError("[TurnManager] Cannot end turn because CurrentCharacter is null!");
            return;
        }

        Debug.Log($"[TurnManager] {CurrentCharacter.name} ends turn. Calling BeginNextTurn after {nextTurnDelay} seconds.");

        OnEndTurn?.Invoke(CurrentCharacter);
        Invoke(nameof(BeginNextTurn), nextTurnDelay);
    }

    void OnCharacterDie(Character character)
    {
        Debug.Log($"[TurnManager] {character.name} has died. Checking win/lose conditions.");

        characters.Remove(character);

        if (character.IsPlayer)
        {
            Debug.Log("[TurnManager] Player has died � you lose!");
        }
        else
        {
            Debug.Log("[TurnManager] Enemy has died � you win!");
        }

        if (characters.Count <= 1)
        {
            Debug.Log("[TurnManager] Combat is over � returning to exploration.");
            // You could add a callback here to exit the battle UI or return to overworld.
        }
    }
}