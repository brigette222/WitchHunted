using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class Character : MonoBehaviour
{
    public int CurHp;
    public int MaxHp;

    public bool IsPlayer;

    public List<CombatAction> CombatActions = new List<CombatAction>();

    private Character opponent;

    private Vector3 startPos;

    public event UnityAction OnHealthChange;
    public static event UnityAction<Character> OnDie;

    private bool actionInProgress = false;  // Added to block repeat actions

    void Start()
    {
        startPos = transform.position;
        Debug.Log($"[Character] {name} (IsPlayer={IsPlayer}) spawned with {CurHp}/{MaxHp} HP.");

        TurnManager.Instance.RegisterCharacter(this);
        Debug.Log($"[Character] {name} registered with TurnManager.");
    }

    public void SetOpponent(Character newOpponent)
    {
        opponent = newOpponent;
        if (opponent != null)
        {
            Debug.Log($"[Character] {name} set opponent to {opponent.name}");
        }
        else
        {
            Debug.LogWarning($"[Character] {name} tried to set opponent, but newOpponent was null!");
        }
    }

    public void AssignOpponent(Character newOpponent)
    {
        SetOpponent(newOpponent);
    }

    public void TakeDamage(int damageToTake)
    {
        CurHp -= damageToTake;
        OnHealthChange?.Invoke();

        Debug.Log($"[Character] {name} took {damageToTake} damage. Current HP: {CurHp}/{MaxHp}");

        if (CurHp <= 0)
        {
            Die();
        }
    }

    void Die()
    {
        Debug.Log($"[Character] {name} has died!");
        OnDie?.Invoke(this);
        Destroy(gameObject);
    }

    public void Heal(int healAmount)
    {
        CurHp += healAmount;
        OnHealthChange?.Invoke();

        Debug.Log($"[Character] {name} healed {healAmount} HP. Current HP: {CurHp}/{MaxHp}");

        if (CurHp > MaxHp)
        {
            CurHp = MaxHp;
        }
    }

    public void CastCombatAction(CombatAction combatAction)
    {
        if (actionInProgress)
        {
            Debug.LogWarning($"[Character] {name} tried to act, but action is already in progress!");
            return;
        }

        Debug.Log($"[Character] {name} casts {combatAction.DisplayName}!");

        if (opponent == null)
        {
            Debug.LogError($"[Character] {name} tried to cast an action, but opponent is NULL!");
            TurnManager.Instance.EndTurn(); // Failsafe to avoid lockup if something went wrong.
            return;
        }

        actionInProgress = true;

        if (combatAction.Damage > 0)
        {
            StartCoroutine(AttackOpponent(combatAction));
        }
        else if (combatAction.ProjectilePrefab != null)
        {
            GameObject proj = Instantiate(combatAction.ProjectilePrefab, transform.position, Quaternion.identity);
            proj.GetComponent<Projectile>().Initialize(opponent, SafeEndTurn);
        }
        else if (combatAction.HealAmount > 0)
        {
            Heal(combatAction.HealAmount);
            SafeEndTurn();
        }
    }

    IEnumerator AttackOpponent(CombatAction combatAction)
    {
        Debug.Log($"[Character] {name} is starting AttackOpponent against {opponent.name}");

        // Move to opponent
        while (Vector3.Distance(transform.position, opponent.transform.position) > 0.1f)
        {
            transform.position = Vector3.MoveTowards(transform.position, opponent.transform.position, 50 * Time.deltaTime);
            yield return null;
        }

        Debug.Log($"[Character] {name} reached {opponent.name} � applying {combatAction.Damage} damage");
        opponent.TakeDamage(combatAction.Damage);

        // Move back to start position
        Debug.Log($"[Character] {name} is now returning to start position");
        while (Vector3.Distance(transform.position, startPos) > 0.1f)
        {
            transform.position = Vector3.MoveTowards(transform.position, startPos, 20 * Time.deltaTime);
            yield return null;
        }

        Debug.Log($"[Character] {name} finished movement � calling EndTurn()");
        SafeEndTurn();
    }

    private void SafeEndTurn()
    {
        if (!actionInProgress)
        {
            Debug.LogWarning($"[Character] {name} tried to EndTurn but action was already ended.");
            return;
        }

        actionInProgress = false;
        TurnManager.Instance.EndTurn();
    }

    public float GetHealthPercentage()
    {
        if (MaxHp <= 0)
        {
            Debug.LogError($"[Character] {name} has MaxHp <= 0, which is invalid!");
            return 0f;
        }

        return (float)CurHp / (float)MaxHp;
    }
}