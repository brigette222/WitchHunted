using UnityEngine;

public class CombatTrigger2D : MonoBehaviour
{
    public GameObject combatUI; // Assign your Combat UI Canvas
    public float detectionRadius = 1.5f;
    public LayerMask enemyLayer; // Set this to "Enemy" layer in Inspector

    private bool inCombat = false;

    void Update()
    {
        if (inCombat) return;

        Collider2D nearbyEnemy = Physics2D.OverlapCircle(transform.position, detectionRadius, enemyLayer);

        if (nearbyEnemy != null)
        {
            Character worldEnemy = nearbyEnemy.GetComponent<Character>();
            if (worldEnemy != null)
            {
                TriggerCombat(worldEnemy);
            }
        }
    }

    void TriggerCombat(Character worldEnemy)
    {
        combatUI.SetActive(true);

        // Find the player�s turn-based version
        PlayerCharacter player = FindObjectOfType<PlayerCharacter>();

        if (player == null)
        {
            Debug.LogError("PlayerCharacter not found in scene!");
            return;
        }

        // Identify which enemy type this is
        string enemyType = worldEnemy.name.Replace("(Clone)", "").Trim();

        // Hide the world enemy (since battle now happens in UI)
        worldEnemy.gameObject.SetActive(false);

        // Find correct combat UI enemy and activate it
        Character combatEnemy = FindCombatUIEnemy(enemyType);
        if (combatEnemy == null)
        {
            Debug.LogError($"No matching combat UI enemy found for '{enemyType}'!");
            return;
        }

        // Set opponents
        player.SetOpponent(combatEnemy);
        combatEnemy.SetOpponent(player);

        // Start combat directly (like you had before)
        TurnManager.Instance.StartCombat(player, combatEnemy);

        // NEW: Let CombatManager handle healthbars only
        CombatManager.Instance.SetupHealthBars(player, combatEnemy);

        inCombat = true; // Lock to prevent re-trigger
    }

    Character FindCombatUIEnemy(string enemyType)
    {
        Character[] allCombatEnemies = combatUI.GetComponentsInChildren<Character>(true);

        foreach (Character enemy in allCombatEnemies)
        {
            if (enemy.name.Contains(enemyType))
            {
                enemy.gameObject.SetActive(true); // Show enemy UI object
                return enemy;
            }
        }

        return null; // Fail if not found
    }

    public void EndCombat()
    {
        combatUI.SetActive(false);
        inCombat = false; // Ready for next fight
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, detectionRadius);
    }
}
