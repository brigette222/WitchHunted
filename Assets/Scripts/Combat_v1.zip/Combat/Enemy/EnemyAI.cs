using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAI : MonoBehaviour
{
    public Character character; // Exposed for debugging in inspector

    [SerializeField] private AnimationCurve healChanceCurve;

    void Awake()
    {
        character = GetComponent<Character>();
        if (character == null)
        {
            Debug.LogError($"[EnemyAI] {name} could not find its Character component on Awake!");
        }
        else
        {
            Debug.Log($"[EnemyAI] {name} linked to Character: {character.name}");
        }
    }

    void OnEnable()
    {
        TurnManager.Instance.OnBeginTurn += OnBeginTurn;
    }

    void OnDisable()
    {
        TurnManager.Instance.OnBeginTurn -= OnBeginTurn;
    }

    void OnBeginTurn(Character c)
    {
        if (character == null)
        {
            Debug.LogError($"[EnemyAI] {name} has no linked Character during OnBeginTurn!");
            return;
        }

        if (character == c)
        {
            Debug.Log($"[EnemyAI] It's {character.name}'s turn (AI). Evaluating action...");
            DetermineCombatAction();
        }
    }

    void DetermineCombatAction()
    {
        if (character == null)
        {
            Debug.LogError($"[EnemyAI] {name} tried to determine action but has no character!");
            TurnManager.Instance.EndTurn(); // Failsafe to prevent lockup
            return;
        }

        float healthPercentage = character.GetHealthPercentage();
        bool wantToHeal = Random.value < healChanceCurve.Evaluate(healthPercentage);

        Debug.Log($"[EnemyAI] {character.name} Health: {character.CurHp}/{character.MaxHp} ({healthPercentage:P}) - Heal Desire: {wantToHeal}");

        CombatAction selectedAction = null;

        if (wantToHeal && HasCombatActionOfType(CombatAction.Type.Heal))
        {
            selectedAction = GetCombatActionOfType(CombatAction.Type.Heal);
            Debug.Log($"[EnemyAI] {character.name} chooses HEAL action: {selectedAction.DisplayName}");
        }
        else if (HasCombatActionOfType(CombatAction.Type.Attack))
        {
            selectedAction = GetCombatActionOfType(CombatAction.Type.Attack);
            Debug.Log($"[EnemyAI] {character.name} chooses ATTACK action: {selectedAction.DisplayName}");
        }

        if (selectedAction != null)
        {
            character.CastCombatAction(selectedAction);
        }
        else
        {
            Debug.LogWarning($"[EnemyAI] {character.name} had no valid action. Ending turn.");
            TurnManager.Instance.EndTurn();
        }
    }

    bool HasCombatActionOfType(CombatAction.Type type)
    {
        if (character == null) return false;
        return character.CombatActions.Exists(x => x.ActionType == type);
    }

    CombatAction GetCombatActionOfType(CombatAction.Type type)
    {
        if (character == null) return null;
        List<CombatAction> availableActions = character.CombatActions.FindAll(x => x.ActionType == type);
        return availableActions[Random.Range(0, availableActions.Count)];
    }
}