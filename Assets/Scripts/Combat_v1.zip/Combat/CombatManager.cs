using UnityEngine;

public class CombatManager : MonoBehaviour
{
    public static CombatManager Instance;

    public GameObject combatUI; // Assign in Inspector

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void SetupHealthBars(Character player, Character enemy)
    {
        HealthBarUI[] healthBars = combatUI.GetComponentsInChildren<HealthBarUI>();

        if (healthBars.Length < 2)
        {
            Debug.LogError("Expected 2 health bars (Player + Enemy), but found " + healthBars.Length);
            return;
        }

        healthBars[0].Setup(player); // Player healthbar
        healthBars[1].Setup(enemy);  // Enemy healthbar
    }
}
