using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class CombatActionUI : MonoBehaviour
{
    [SerializeField] private GameObject visualContainer;
    [SerializeField] private Button[] combatActionButtons;

    void OnEnable()
    {
        Debug.Log("[CombatActionUI] OnEnable fired � Subscribing to TurnManager events.");
        TurnManager.Instance.OnBeginTurn += OnBeginTurn;
        TurnManager.Instance.OnEndTurn += OnEndTurn;
    }

    void OnDisable()
    {
        Debug.Log("[CombatActionUI] OnDisable fired � Unsubscribing from TurnManager events.");
        TurnManager.Instance.OnBeginTurn -= OnBeginTurn;
        TurnManager.Instance.OnEndTurn -= OnEndTurn;
    }

    void OnBeginTurn(Character character)
    {
        Debug.Log($"[CombatActionUI] OnBeginTurn fired � Character: {character.name}, IsPlayer: {character.IsPlayer}");

        if (!character.IsPlayer)
        {
            Debug.Log("[CombatActionUI] Skipping UI update � it's the enemy's turn.");
            return;
        }

        visualContainer.SetActive(true);
        Debug.Log("[CombatActionUI] Player's turn � Showing action buttons.");

        for (int i = 0; i < combatActionButtons.Length; i++)
        {
            if (i < character.CombatActions.Count)
            {
                CombatAction ca = character.CombatActions[i];

                combatActionButtons[i].gameObject.SetActive(true);
                combatActionButtons[i].GetComponentInChildren<TextMeshProUGUI>().text = ca.DisplayName;

                combatActionButtons[i].onClick.RemoveAllListeners();
                combatActionButtons[i].onClick.AddListener(() => OnClickCombatAction(ca));

                Debug.Log($"[CombatActionUI] Button {i} set to action: {ca.DisplayName}");
            }
            else
            {
                combatActionButtons[i].gameObject.SetActive(false);
            }
        }
    }

    void OnEndTurn(Character character)
    {
        Debug.Log($"[CombatActionUI] OnEndTurn fired � Character: {character.name}");
        visualContainer.SetActive(false);
    }

    public void OnClickCombatAction(CombatAction combatAction)
    {
        Debug.Log($"[CombatActionUI] Player clicked action: {combatAction.DisplayName}");
        TurnManager.Instance.CurrentCharacter.CastCombatAction(combatAction);
    }
}