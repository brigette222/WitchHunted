using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class HealthBarUI : MonoBehaviour
{
    [SerializeField] private Image healthFill;
    [SerializeField] private TextMeshProUGUI healthText;

    private Character character;

    void OnEnable()
    {
        if (character != null)
        {
            character.OnHealthChange += OnUpdateHealth;
            Debug.Log($"[HealthBarUI] OnEnable � Subscribed to {character.name}'s health change event.");
        }
        else
        {
            Debug.LogWarning("[HealthBarUI] OnEnable fired, but character is NULL � this is usually fine if Setup() hasn't been called yet.");
        }
    }

    void OnDisable()
    {
        if (character != null)
        {
            character.OnHealthChange -= OnUpdateHealth;
            Debug.Log($"[HealthBarUI] OnDisable � Unsubscribed from {character.name}'s health change event.");
        }
    }

    void Start()
    {
        if (character != null)
        {
            Debug.Log($"[HealthBarUI] Start � Initial health update for {character.name}.");
            OnUpdateHealth();
        }
        else
        {
            Debug.LogWarning("[HealthBarUI] Start ran with no character assigned � this is expected if Setup() runs later.");
        }
    }

    void OnUpdateHealth()
    {
        if (character != null)
        {
            healthFill.fillAmount = character.GetHealthPercentage();
            healthText.text = $"{character.CurHp} / {character.MaxHp}";
            Debug.Log($"[HealthBarUI] Health updated for {character.name}: {character.CurHp}/{character.MaxHp}");
        }
        else
        {
            Debug.LogError("[HealthBarUI] OnUpdateHealth fired but character is NULL! This should never happen if Setup() worked correctly.");
        }
    }

    public void Setup(Character assignedCharacter)
    {
        if (character != null)
        {
            character.OnHealthChange -= OnUpdateHealth;
            Debug.Log($"[HealthBarUI] Setup � Unsubscribed from old character {character.name} (if any).");
        }

        character = assignedCharacter;

        if (character != null)
        {
            character.OnHealthChange += OnUpdateHealth;
            Debug.Log($"[HealthBarUI] Setup � Subscribed to new character {character.name}.");
            OnUpdateHealth();
        }
        else
        {
            Debug.LogError("[HealthBarUI] Setup called with NULL character!");
        }
    }
}