using UnityEngine;
using System.Collections;

public class CombatTrigger2D : MonoBehaviour
{
    public GameObject combatUI;
    public float detectionRadius = 1.5f;
    public LayerMask enemyLayer;

    private bool inCombat = false;

    void Update()
    {
        if (inCombat) return;

        Collider2D nearbyEnemy = Physics2D.OverlapCircle(transform.position, detectionRadius, enemyLayer);
        if (nearbyEnemy != null)
        {
            Character worldEnemy = nearbyEnemy.GetComponent<Character>();
            if (worldEnemy != null)
            {
                TriggerCombat(worldEnemy);
            }
        }
    }

    void TriggerCombat(Character worldEnemy)
    {
        Debug.Log("[CombatTrigger2D] Starting combat...");

        // ? DO NOT pause yet � wait for combat setup to finish

        TransitionAnimator.StartCombatTransition(() =>
        {
            // Find player character in the UI
            Character player = FindCombatUIPlayer();
            if (player == null)
            {
                Debug.LogError("[CombatTrigger2D] Combat UI PlayerCharacter not found!");
                return;
            }

            // Clean up world enemy
            string enemyType = worldEnemy.name.Replace("(Clone)", "").Trim();
            worldEnemy.gameObject.SetActive(false);

            // Find enemy character in the UI
            Character combatEnemy = FindCombatUIEnemy(enemyType);
            if (combatEnemy == null)
            {
                Debug.LogError($"[CombatTrigger2D] No matching combat UI enemy found for '{enemyType}'!");
                return;
            }

            // Enable and prepare both characters
            player.gameObject.SetActive(true);
            combatEnemy.gameObject.SetActive(true);

            player.ResetCharacter();
            combatEnemy.ResetCharacter();

            player.ResetStartPos();
            combatEnemy.ResetStartPos();

            player.SetOpponent(combatEnemy);
            combatEnemy.SetOpponent(player);

            TurnManager.Instance.StartCombat(player, combatEnemy);
            CombatManager.Instance.SetupHealthBars(player, combatEnemy);

            // ? Pause overworld logic via PauseManager
            if (PauseManager.Instance != null && PauseManager.Instance.CurrentPauseType == PauseType.None)
            {
                PauseManager.Instance.Pause(PauseType.Combat);
                Debug.Log("[CombatTrigger2D] PauseManager ? Combat pause triggered");
            }

            inCombat = true;
        });
    }

    Character FindCombatUIPlayer()
    {
        return combatUI.GetComponentInChildren<PlayerCharacter>(true);
    }

    Character FindCombatUIEnemy(string enemyType)
    {
        Character[] allCombatEnemies = combatUI.GetComponentsInChildren<Character>(true);
        Character selectedEnemy = null;

        foreach (Character enemy in allCombatEnemies)
        {
            if (enemy.name.Contains(enemyType))
            {
                enemy.gameObject.SetActive(true);
                selectedEnemy = enemy;
                Debug.Log($"[CombatTrigger2D] Activating UI enemy: {enemy.name}");
            }
            else
            {
                enemy.gameObject.SetActive(false);
                Debug.Log($"[CombatTrigger2D] Hiding UI enemy: {enemy.name}");
            }
        }

        if (selectedEnemy == null)
        {
            Debug.LogError($"[CombatTrigger2D] No matching combat UI enemy found for '{enemyType}'!");
        }

        return selectedEnemy;
    }

    public void EndCombat()
    {
        Debug.Log("[CombatTrigger2D] Ending combat and resetting state.");
        combatUI.SetActive(false);

        if (PauseManager.Instance != null && PauseManager.Instance.CurrentPauseType == PauseType.Combat)
        {
            PauseManager.Instance.Resume();
            Debug.Log("[CombatTrigger2D] PauseManager ? Combat pause ended");
        }

        // ? Should still be here
        MusicManager musicManager = FindObjectOfType<MusicManager>();
        if (musicManager != null)
        {
            musicManager.EndCombatMusic();
        }

        inCombat = false;
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, detectionRadius);
    }
}