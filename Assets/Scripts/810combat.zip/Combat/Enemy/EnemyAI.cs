using UnityEngine;

public class EnemyAI : MonoBehaviour
{
    public Character character;

    void Awake()
    {
        character = GetComponent<Character>();
        if (character == null)
        {
            Debug.LogError($"[EnemyAI] {name} could not find its Character component!");
        }
    }

    void OnEnable()
    {
        if (TurnManager.Instance != null)
        {
            TurnManager.Instance.OnBeginTurn += OnBeginTurn;
        }
        else
        {
            Debug.LogError("[EnemyAI] ERROR: TurnManager instance is NULL!");
        }
    }

    void OnDisable()
    {
        if (TurnManager.Instance != null)
        {
            TurnManager.Instance.OnBeginTurn -= OnBeginTurn;
        }
    }

    void OnBeginTurn(Character activeCharacter)
    {
        if (character == activeCharacter)
        {
            Character player = FindPlayerCharacter();
            if (player == null)
            {
                Debug.LogError($"[EnemyAI] Could not find player character!");
                return;
            }

            CombatAction chosenAction = DecideAction(player);
            character.CastCombatAction(chosenAction);
        }
    }

    Character FindPlayerCharacter()
    {
        foreach (Character combatant in FindObjectsOfType<Character>())
        {
            if (combatant.IsPlayer)
            {
                return combatant;
            }
        }
        return null;
    }

    CombatAction DecideAction(Character player)
    {
        if (character.CombatActions.Count == 0)
        {
            Debug.LogError($"[EnemyAI] {character.name} has no combat actions assigned!");
            return null;
        }

        // If the enemy has healing abilities and is at low HP, prioritize healing.
        foreach (CombatAction action in character.CombatActions)
        {
            if (action.HealAmount > 0 && character.CurHp <= character.MaxHp * 0.3f) // Heal if below 30% HP
            {
                Debug.Log($"[EnemyAI] {character.name} is low on HP! Choosing healing action: {action.DisplayName}");
                return action;
            }
        }

        // If the player's HP is low, use a weaker attack instead of a strong one
        if (player.CurHp <= player.MaxHp * 0.3f) // If player HP is below 30%
        {
            foreach (CombatAction action in character.CombatActions)
            {
                if (action.Damage <= 15) // Only use attacks with low damage
                {
                    Debug.Log($"[EnemyAI] {character.name} sees player is weak! Choosing weaker attack: {action.DisplayName}");
                    return action;
                }
            }
        }

        // If no special condition is met, pick a random attack from the list.
        CombatAction randomAttack = character.CombatActions[Random.Range(0, character.CombatActions.Count)];
        Debug.Log($"[EnemyAI] {character.name} is choosing a random attack: {randomAttack.DisplayName}");
        return randomAttack;
    }
}
