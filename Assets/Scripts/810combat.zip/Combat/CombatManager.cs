using UnityEngine;
using static CombatAction;
using System.Collections;

public class CombatManager : MonoBehaviour
{
    public static CombatManager Instance;
    public GameObject combatUI;
    private HealthBarUI playerHealthBar;
    private HealthBarUI enemyHealthBar;

    private CombatAction currentCombatAction;

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void SetupHealthBars(Character player, Character enemy)
    {
        Debug.Log("[CombatManager] SetupHealthBars() was called!");

        if (player == null || enemy == null)
        {
            Debug.LogError("[CombatManager] Player or Enemy is NULL! Cannot assign health bars.");
            return;
        }

        playerHealthBar = combatUI.GetComponentInChildren<HealthBarUI>(true);
        enemyHealthBar = enemy.GetComponentInChildren<HealthBarUI>(true);

        if (playerHealthBar == null || enemyHealthBar == null)
        {
            Debug.LogError("[CombatManager] Could not find proper health bars! Check UI element hierarchy.");
            return;
        }

        playerHealthBar.Setup(player);
        enemyHealthBar.Setup(enemy);
    }

    public void EndCombat()
    {
        StartCoroutine(DelayedCombatEnd());
    }

    IEnumerator DelayedCombatEnd()
    {
        TransitionAnimator.EndCombatTransition(() =>
        {
            FindObjectOfType<PlayerNeeds>().SyncHealthFromCombat();

            CombatTrigger2D combatTrigger = FindObjectOfType<CombatTrigger2D>();
            if (combatTrigger != null)
            {
                combatTrigger.EndCombat();
            }

            TurnManager.Instance.ClearCombatState();
        });

        yield return null; // transition handles timing
    }

    public void SetCurrentCombatAction(CombatAction action)
    {
        currentCombatAction = action;
        Debug.Log($"[CombatManager] Current combat action set to: {action.DisplayName}");
    }

    public CombatAction GetCurrentCombatAction()
    {
        return currentCombatAction;
    }

    public void ExecuteAction(Character caster, Character target, CombatAction action)
    {
        if (action == null)
        {
            Debug.LogError("[CombatManager] No combat action provided!");
            return;
        }

        SetCurrentCombatAction(action);
        bool isHealing = action.ActionType == CombatAction.Type.Heal;

        if (isHealing)
        {
            caster.Heal(action.HealAmount);
        }
        else
        {
            target.TakeDamage(action.Damage);
        }
    }


}

