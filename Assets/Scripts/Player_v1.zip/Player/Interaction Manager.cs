using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.InputSystem;

public class InteractionManager : MonoBehaviour
{
    public float checkRate = 0.05f;
    private float lastCheckTime;
    public float maxCheckDistance = 0.8f;
    public LayerMask layerMask;

    private GameObject curInteractGameObject;
    private IInteractable curInteractable;

    public TextMeshProUGUI promptText;

    void Start()
    {
        promptText.gameObject.SetActive(false);
    }

    void Update()
    {
        if (Time.time - lastCheckTime > checkRate)
        {
            lastCheckTime = Time.time;

            Collider2D hit = Physics2D.OverlapCircle(transform.position, maxCheckDistance, layerMask);

            if (hit != null)
            {
                if (hit.gameObject != curInteractGameObject)
                {
                    curInteractGameObject = hit.gameObject;
                    curInteractable = hit.GetComponent<IInteractable>();

                    if (curInteractable != null)
                    {
                        Debug.Log("Interactable object found: " + hit.gameObject.name);
                        SetPromptText();
                    }
                    else
                    {
                        curInteractGameObject = null;
                        curInteractable = null;
                        promptText.gameObject.SetActive(false);
                    }
                }
            }
            else
            {
                curInteractGameObject = null;
                curInteractable = null;
                promptText.gameObject.SetActive(false);
            }
        }

        // MANUALLY CHECK FOR E KEY WITHOUT INPUT SYSTEM
        if (Input.GetKeyDown(KeyCode.E))
        {
            Debug.Log("E key pressed. Checking interaction...");

            if (curInteractable != null)
            {
                Debug.Log("Attempting to interact with: " + curInteractGameObject.name);
                curInteractable.OnInteract();
                Debug.Log("Interaction completed.");

                curInteractGameObject = null;
                curInteractable = null;
                promptText.gameObject.SetActive(false);
            }
            else
            {
                Debug.LogWarning("Tried to interact, but no valid object was detected!");
            }
        }
    }

    public void OnInteractInput(InputAction.CallbackContext context)
    {
        if (context.phase == InputActionPhase.Started)
        {
            Debug.Log("E key pressed. Checking interaction...");

            if (curInteractable != null)
            {
                Debug.Log("Attempting to interact with: " + curInteractGameObject.name);

                curInteractable.OnInteract();

                Debug.Log("Interaction completed.");

                curInteractGameObject = null;
                curInteractable = null;
                promptText.gameObject.SetActive(false);
            }
            else
            {
                Debug.LogWarning("Tried to interact, but no valid object was detected!");
            }
        }
    }

    void SetPromptText()
    {
        if (curInteractable != null)
        {
            promptText.gameObject.SetActive(true);
            promptText.text = "[E] " + curInteractable.GetInteractPrompt();
        }
    }
}

public interface IInteractable
{
    string GetInteractPrompt();
    void OnInteract();
}