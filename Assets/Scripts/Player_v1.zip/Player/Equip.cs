using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Equip : MonoBehaviour
{
    public virtual void OnAttackInput()
    {

    }

    public virtual void OnAltAttackInput()
    {

    }
}
