using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;

public class PlayerNeeds : MonoBehaviour, IDamagable
{
    public Need health;
    public Need magik;
    public Need hunger;
    public Need stamina;

    public float noHungerHealthDecay;
    public float noThirstHealthDecay;

    public UnityEvent onTakeDamage;

    void Start()
    {
        {
            health.uiBar = GameObject.Find("Health Value").GetComponent<Image>();
            hunger.uiBar = GameObject.Find("Hunger Value").GetComponent<Image>();
            magik.uiBar = GameObject.Find("Magik Value").GetComponent<Image>();
            stamina.uiBar = GameObject.Find("Stamina Value").GetComponent<Image>();

            // Initialize start values
            health.curValue = health.startValue;
            hunger.curValue = hunger.startValue;
            magik.curValue = magik.startValue;
            stamina.curValue = stamina.startValue;
        }

        // Force UI update at start
        UpdateUI();
    }

    void Update()
    {
        // Decay needs over time
        hunger.Subtract(hunger.decayRate * Time.deltaTime);
        magik.Subtract(magik.decayRate * Time.deltaTime);
        stamina.Add(stamina.regenRate * Time.deltaTime);

        // Decay health over time if no hunger or thirst
        if (hunger.curValue == 0.0f)
            health.Subtract(noHungerHealthDecay * Time.deltaTime);
        if (magik.curValue == 0.0f)
            health.Subtract(noThirstHealthDecay * Time.deltaTime);

        // Check if player is dead
        if (health.curValue == 0.0f)
        {
            Die();
        }

        // Update UI
        UpdateUI();
    }

    public void UpdateUI()
    {
        if (health.uiBar != null) health.uiBar.fillAmount = Mathf.Clamp01(health.GetPercentage());
        if (hunger.uiBar != null) hunger.uiBar.fillAmount = Mathf.Clamp01(hunger.GetPercentage());
        if (magik.uiBar != null) magik.uiBar.fillAmount = Mathf.Clamp01(magik.GetPercentage());
        if (stamina.uiBar != null) stamina.uiBar.fillAmount = Mathf.Clamp01(stamina.GetPercentage());
    }

    public void Heal(float amount) { health.Add(amount); }
    public void Eat(float amount) { hunger.Add(amount); }
    public void Drink(float amount) { magik.Add(amount); }
    public void Sleep(float amount) { stamina.Subtract(amount); }

    public void TakePhysicalDamage(int amount)
    {
        health.Subtract(amount);
        onTakeDamage?.Invoke();
    }

    public void Die()
    {
        Debug.Log("Player is dead");
    }
}

[System.Serializable]
public class Need
{
    [HideInInspector] public float curValue;
    public float maxValue;
    public float startValue;
    public float regenRate;
    public float decayRate;
    public Image uiBar;

    public void Add(float amount) { curValue = Mathf.Min(curValue + amount, maxValue); }
    public void Subtract(float amount) { curValue = Mathf.Max(curValue - amount, 0.0f); }
    public float GetPercentage() { return curValue / maxValue; }
}

public interface IDamagable
{
    void TakePhysicalDamage(int damageAmount);
}