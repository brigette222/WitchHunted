using UnityEngine;

public class CamFollow : MonoBehaviour
{
    public float followSpeed = 2f; // Speed of camera following
    public float xOffset = 0f;    // Horizontal offset
    public float yOffset = 1f;    // Vertical offset
    public float zoomOutSize = 5f; // Zoom out level (for Orthographic camera)
    public Transform target;      // Target to follow

    private Camera cam;

    void Start()
    {
        // Get the Camera component attached to this GameObject
        cam = GetComponent<Camera>();

        if (cam == null)
        {
        }

        // Apply zoom out if the camera is orthographic
        if (cam.orthographic)
        {
            cam.orthographicSize = zoomOutSize;
        }
    }

    void LateUpdate()
    {
        if (target == null)
        {
            return;
        }

        // Calculate the target position for the camera
        Vector3 targetPosition = new Vector3(
            target.position.x + xOffset,
            target.position.y + yOffset,
            -10f // Keep a fixed Z position for 2D
        );

        // Smoothly interpolate the camera position
        transform.position = Vector3.Lerp(transform.position, targetPosition, followSpeed * Time.deltaTime);
    }
}
